# Object Detection and Annotation Application

This project is a Flask-based web application that allows users to upload a video file, process it using YOLOv8 for object detection, and receive an annotated video with bounding boxes and labels for detected objects.

## Table of Contents

- [Features](#features)
- [Requirements](#requirements)
- [Installation](#installation)
- [Usage](#usage)
- [Example](#example)
- [License](#license)

## Features

- Upload MP4 video files.
- Detect objects in the video using YOLOv8.
- Annotate the video with bounding boxes and class labels.
- Download the annotated video.

## Requirements

- Python 3.7 or higher
- Flask
- OpenCV
- Ultralytics YOLO
- Other dependencies listed in `requirements.txt`

## Installation

1. Access the app through this repository:

   git clone https://github.com/jnunes83/computer_vision

2. Create a virtual environment (optional but recommended):

python -m venv venv
source venv/bin/activate  # On Windows use `venv\Scripts\activate`

3. Install the required packages:

4. Download the YOLOv8 model weights and place them in the project directory. You can use the following command to download the model:

wget https://github.com/ultralytics/yolov8/releases/download/v8.0/yolov8s.pt

Usage
Run the Flask application:

 copy
bash

python app.py
Open your web browser and go to http://127.0.0.1:5000/.

Use the provided form to upload an MP4 video file.

After uploading, the application will process the video and provide a downloadable link for the annotated video.

Example
Here's a brief example of how to use the application:

Start the server:

 copy
bash

python app.py
Access the application in your browser:

 copy
http://127.0.0.1:5000/
Upload a video file and wait for the processing to complete.

Download the annotated video with detected objects labeled.







