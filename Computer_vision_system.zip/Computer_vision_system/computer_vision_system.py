#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import os
import cv2
import numpy as np
import torch
from ultralytics import YOLO
from flask import Flask, request, render_template, send_file

app = Flask(__name__)
device = "cuda" if torch.cuda.is_available() else "cpu"

def extract_frames(video_path):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Error: Could not open video file {video_path}")
        return []

    frames = []
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        frames.append(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    cap.release()
    return frames

def yolov8_detection(frames, model_path="yolov8s.pt"):
    model = YOLO(model_path)
    results = []
    for frame in frames:
        detections = model(frame)
        results.append(detections)  # Store the detections for each frame
    return results, model  # Return both results and the model

def annotate_video(frames, detections, model, video_path):
    if not frames:
        print("Error: No frames to annotate.")
        return

    output_path = os.path.splitext(video_path)[0] + '_annotated.mp4'
    height, width, _ = frames[0].shape
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter(output_path, fourcc, 20.0, (width, height))

    for frame, detection in zip(frames, detections):
        annotated_frame = frame.copy()
        # Check if detections have results
        if detection is not None and len(detection) > 0:
            # Iterate over the detections
            for det in detection[0].boxes.data:  # Accessing the boxes directly
                x1, y1, x2, y2, conf, cls = det.cpu().numpy()  # Convert to numpy
                label = f"{model.names[int(cls)]}: {conf:.2f}"
                # Draw bounding box
                cv2.rectangle(annotated_frame, (int(x1), int(y1)), (int(x2), int(y2)), (255, 0, 0), 2)
                # Put label
                cv2.putText(annotated_frame, label, (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

        out.write(cv2.cvtColor(annotated_frame, cv2.COLOR_RGB2BGR))

    out.release()
    return output_path

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        if 'video' not in request.files:
            return "No file part"
        video_file = request.files['video']
        if video_file.filename == '':
            return "No selected file"
        if video_file and video_file.filename.endswith('.mp4'):
            video_path = os.path.join('uploads', video_file.filename)
            video_file.save(video_path)

            frames = extract_frames(video_path)
            detections, model = yolov8_detection(frames)  # Get detections and model
            output_path = annotate_video(frames, detections, model, video_path)  # Pass model to annotate_video
            return send_file(output_path, as_attachment=True)

    return render_template('upload.html')

if __name__ == '__main__':
    if not os.path.exists('uploads'):
        os.makedirs('uploads')
    app.run(debug=True, use_reloader=False)


# In[ ]:


get_ipython().system('python -m flask run')


# In[ ]:




